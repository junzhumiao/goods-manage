package com.qhx.admin.controller.system;

import com.github.pagehelper.PageInfo;
import com.qhx.admin.domain.Message;
import com.qhx.admin.model.to.message.MessDeleteTo;
import com.qhx.admin.model.to.message.MessQueryTo;
import com.qhx.admin.service.MessageService;
import com.qhx.common.controller.BaseController;
import com.qhx.common.model.AjaxResult;
import com.qhx.common.model.PageResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author qhx2004
 * @since 2024-03-11
 */
@RestController
@RequestMapping("/message")
public class MessageController extends BaseController
{
    
    @Autowired
    private MessageService messageService;


    @RequestMapping(path = "/getAll")
    @ApiOperation("获取全部消息")
    public PageResult getAll(MessQueryTo messQueryTo){
        Integer page = messQueryTo.getPage();
        Integer pageSize = messQueryTo.getPageSize();
        PageInfo pageInfo = startOrderPage(page, pageSize, () ->
        {
           messageService.getAllMes(messQueryTo);
        });
        return toAjax(pageInfo);
    }


    @RequestMapping(path = "/delete",method = RequestMethod.POST)
    @ApiOperation("删除消息")
    public AjaxResult delete(MessDeleteTo messDeleteTo){
        boolean end = messageService.deleteMes(messDeleteTo);
        return toAjax(end);
    }


    @RequestMapping(path = "/updateStatus")
    @ApiOperation("修改消息状态(审核消息)")
    public AjaxResult updateStatus(@RequestBody Message message){
        boolean end = messageService.updateStatus(message);
        return toAjax(end);
    }






}
