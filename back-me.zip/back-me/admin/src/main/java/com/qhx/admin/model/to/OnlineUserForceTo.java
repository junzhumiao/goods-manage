package com.qhx.admin.model.to;

import lombok.Data;

/**
 * @author: jzm
 * @date: 2024-03-29 10:38
 **/

@Data
public class OnlineUserForceTo
{
    private Long userId;
}
