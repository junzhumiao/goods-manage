package com.qhx.admin.model.to.backUser;

import com.qhx.common.model.to.user.UserDeleteTo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @author: jzm
 * @date: 2024-03-02 09:05
 **/

@AllArgsConstructor
public class BackUserDeleteTo extends UserDeleteTo
{
}
