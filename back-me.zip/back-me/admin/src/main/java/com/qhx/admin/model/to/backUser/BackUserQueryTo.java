package com.qhx.admin.model.to.backUser;


import com.qhx.common.model.to.user.UserQueryTo;
import lombok.Getter;
import lombok.Setter;

/**
 * 后端用户查询
 *
 * @author: jzm
 * @date: 2024-03-03 21:07
 **/


public class BackUserQueryTo extends UserQueryTo
{

}
