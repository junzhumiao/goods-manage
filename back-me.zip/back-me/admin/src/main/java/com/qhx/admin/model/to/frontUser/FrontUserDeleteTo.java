package com.qhx.admin.model.to.frontUser;

import com.qhx.common.model.to.user.UserDeleteTo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author: jzm
 * @date: 2024-03-07 14:42
 **/

@AllArgsConstructor
public class FrontUserDeleteTo extends UserDeleteTo
{
}
