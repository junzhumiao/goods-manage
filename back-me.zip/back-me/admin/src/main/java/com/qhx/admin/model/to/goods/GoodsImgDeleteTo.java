package com.qhx.admin.model.to.goods;

import lombok.Data;

import java.util.List;

/**
 * @author: jzm
 * @date: 2024-03-27 10:12
 **/

@Data
public class GoodsImgDeleteTo
{
    private List<Long> imgIds;
}
