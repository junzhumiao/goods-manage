package com.qhx.admin.model.vo;

import lombok.Data;

/**
 * @author: jzm
 * @date: 2024-03-26 14:49
 **/

@Data
public class CategoryVo
{
    private Long categoryId;
    private String categoryName;
}
