package com.qhx.admin.model.vo.index;

import lombok.Data;

/**
 * @author: jzm
 * @date: 2024-03-21 15:42
 **/

@Data
public class IndexCountVo
{
    private String goodsCount;
    private String userCount;
    private String orderCount;
    private String shopCount;
}
