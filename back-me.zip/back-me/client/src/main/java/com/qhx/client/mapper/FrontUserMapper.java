package com.qhx.client.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qhx.client.domain.FrontUser;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FrontUserMapper extends BaseMapper<FrontUser>
{
}
