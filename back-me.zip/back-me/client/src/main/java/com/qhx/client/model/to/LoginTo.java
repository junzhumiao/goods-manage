package com.qhx.client.model.to;

import lombok.Data;

/**
 * @author: jzm
 * @date: 2024-02-28 17:50
 **/

@Data
public class LoginTo
{
    private String phone;
    private String password;
}
