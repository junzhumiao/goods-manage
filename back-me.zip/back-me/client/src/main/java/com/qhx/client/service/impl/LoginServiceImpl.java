package com.qhx.client.service.impl;

import com.qhx.client.service.LoginService;
import org.springframework.stereotype.Service;

/**
 * @author: jzm
 * @date: 2024-03-17 09:26
 **/

@Service
public class LoginServiceImpl implements LoginService
{
}
