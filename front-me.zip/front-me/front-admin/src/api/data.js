const commColor = {
	0: "primary",
	1: "danger",
}


export {
	commColor
}