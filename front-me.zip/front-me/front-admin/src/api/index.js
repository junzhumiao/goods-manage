import request from "@/utils/request";

let urlPrefix = '/index'

function getIndexCount() {

    return request({
        method: 'get',
        url: `${urlPrefix}/count`,
    })

}


function getIndexMain() {

    return request({
        method: 'get',
        url: `${urlPrefix}/main`,
    })

}

export {
    getIndexCount,
    getIndexMain
}