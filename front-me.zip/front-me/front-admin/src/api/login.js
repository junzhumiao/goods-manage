import request from "@/utils/request";
import $store from '../store/index'



function getCaptcha() {

    return request({
        method: 'get',
        url: '/get/captcha',
    })

}

function submitLogin({ code, form, remePass }) {
    return request({
        method: 'post',
        url: '/login',
        headers: {
            "captcha-val": code.val,
            "captcha-key": code.key,
            'remember-pass': remePass,
            'X-Client-Id': $store.state.XClientId
        },
        data: {
            username: form.username,
            password: form.password
        },

    })

}


function submitRegister(data) {
    return request({
        method: 'post',
        url: '/register',
        data
    })

}


function submitLogout() {
    return request({
        method: 'post',
        url: '/logout',
    })

}




export {
    getCaptcha,
    submitLogin,
    submitRegister,
    submitLogout,
}