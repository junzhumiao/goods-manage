

import request from "@/utils/request";

function getServer() {

    return request({
        method: 'get',
        url: '/monitor/server',
    })

}


function getCache() {

    return request({
        method: 'get',
        url: '/monitor/cache',
    })

}


export {
    getServer, getCache
}