

import request from "@/utils/request";

let urlPrefix = '/monitor/chain'

function getNodeList() {

    return request({
        method: 'get',
        url: `${urlPrefix}/getNodeList`,
    })

}

function getTransactionTotal() {

    return request({
        method: 'get',
        url: `${urlPrefix}/getTxTotal`,
    })

}

function getSearchBlock(params) {

    return request({
        method: 'get',
        url: `${urlPrefix}/searchBlock`,
        params
    })

}




export {
    getNodeList,
    getTransactionTotal,
    getSearchBlock
}