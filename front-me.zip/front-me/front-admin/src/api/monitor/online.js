
import request from "@/utils/request";

let urlPrefix = '/monitor/online'

function getAllUser(data) {

    return request({
        method: 'post',
        url: `${urlPrefix}/getAllUser`,
        data
    })

}

function forceUser(data) {

    return request({
        method: 'post',
        url: `${urlPrefix}forceUser`,
        data
    })

}


export {
    getAllUser,
    forceUser
}