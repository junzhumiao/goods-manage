// 个人中心
import request from "@/utils/request";

let urlPrefix = '/category'

function createCategory(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}


function removeCategory(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/remove`,
        data
    })
}


function updateCategory(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update`,
        data
    })
}

function updateCategoryStatus(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/status`,
        data
    })
}


function getAllCategory(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/get/all`,
        data
    })
}


function getOneCategory() {
    return request({
        method: 'get',
        url: `${urlPrefix}/get/one`
    })
}




export {
    updateCategory,
    getAllCategory,
    getOneCategory,
    createCategory,
    removeCategory,
    updateCategoryStatus
}