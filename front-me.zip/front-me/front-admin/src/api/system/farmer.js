import request from "@/utils/request";

let urlPrefix = '/farmer'

function getAllFarmer(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/get/all`,
        data
    })
}


function createFarmer(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}


function removeFarmer(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/delete`,
        data
    })
}


function updateFarmer(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update`,
        data
    })
}

function updateFarmerStatus(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/status`,
        data
    })
}


function getOneFarmer(params) {
    return request({
        method: 'get',
        url: `${urlPrefix}/get/one`,
        params
    })
}

function updatePass(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/pass`,
        data
    })
}

export {
    getAllFarmer,
    removeFarmer,
    updateFarmer,
    getOneFarmer,
    updatePass,
    createFarmer,
    updateFarmerStatus
}