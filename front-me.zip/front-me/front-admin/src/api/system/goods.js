import request from "@/utils/request";

let urlPrefix = '/goods'


function getAllGoods(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/get/all`,
        data
    })
}

function getOneGoods(data) {
    return request({
        method: 'get',
        url: `${urlPrefix}/get/one`,
        data
    })
}


function createGoods(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}


function removeGoods(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/delete`,
        data
    })
}

function removeGoodsImg(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/delete/goods/img`,
        data
    })
}



function updateGoods(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update`,
        data
    })
}



function updateGoodsStatus(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/status`,
        data
    })
}




export {
    getAllGoods,
    removeGoods,
    removeGoodsImg,
    updateGoods,
    getOneGoods,
    createGoods,
    updateGoodsStatus
}