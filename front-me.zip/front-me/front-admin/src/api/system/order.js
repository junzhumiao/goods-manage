import request from "@/utils/request";

let urlPrefix = '/order'


function getAllOrder(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/get/all`,
        data
    })
}

function getOneOrder(data) {
    return request({
        method: 'get',
        url: `${urlPrefix}/get/one`,
        data
    })
}



function createOrder(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}


function removeOrder(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/delete`,
        data
    })
}


function updateOrder(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update`,
        data
    })
}



function updateOrderStatus(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/status`,
        data
    })
}

function updateOrderRefund(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/refund`,
        data
    })
}

function updateOrderCancel(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/cancel`,
        data
    })
}





export {
    getAllOrder,
    removeOrder,
    updateOrder,
    getOneOrder,
    createOrder,
    updateOrderStatus,
    updateOrderRefund,
    updateOrderCancel
}