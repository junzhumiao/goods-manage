// 个人中心
import request from "@/utils/request";

let urlPrefix = '/shop'

function updateShop(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update`,
        data
    })
}


function getOneShop() {
    return request({
        method: 'get',
        url: `${urlPrefix}/get/one`
    })
}

function openShop(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/open`,
        data
    })
}

function updateShopAvatar(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/avatar`,
        data
    })
}



export {
    updateShop,
    getOneShop,
    openShop,
    updateShopAvatar
}