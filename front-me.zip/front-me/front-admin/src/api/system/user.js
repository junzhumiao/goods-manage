import request from "@/utils/request";

let urlPrefix = '/front/user'


function getAllUser(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/get/all`,
        data
    })
}

function checkInviCode(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/check/inviCode`,
        data
    })
}

function createUser(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}


function removeUser(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/delete`,
        data
    })
}


function updateUser(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update`,
        data
    })
}

function updateUserStatus(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/status`,
        data
    })
}

function getOneUser(params) {
    return request({
        method: 'get',
        url: `${urlPrefix}/get/one`,
        params
    })
}


function getOneUserByPhone(params) {
    return request({
        method: 'get',
        url: `${urlPrefix}/get/one/phone`,
        params
    })
}

function updatePass(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update/pass`,
        data
    })
}


export {
    getAllUser,
    removeUser,
    updateUser,
    getOneUser,
    updatePass,
    updateUserStatus,
    createUser,
    checkInviCode,
    getOneUserByPhone
}