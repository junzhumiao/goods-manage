import request from "@/utils/request";

let urlPrefix = '/upload'

function uploadAvatar(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/avatar`,
        data,
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    })
}


function uploadGoodsImg(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/goods/img`,
        data,
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    })
}

export {
    uploadAvatar,
    uploadGoodsImg
}