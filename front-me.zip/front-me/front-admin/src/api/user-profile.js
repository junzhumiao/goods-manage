// 个人中心
import request from "@/utils/request";

// 用户修改密码
function updatePass(data) {
    return request({
        method: 'post',
        url: '/update/pass',
        data
    })
}


function updateAvatar(data) {
    return request({
        method: 'post',
        url: '/update/avatar',
        data
    })
}


function getUserInfo() {
    return request({
        method: 'get',
        url: '/get/user',
    })
}

function updateUser(data) {
    return request({
        method: 'post',
        url: '/update/user',
        data
    })
}






export {
    updatePass,
    getUserInfo,
    updateUser,
    updateAvatar
}