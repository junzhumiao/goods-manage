<template>
	<div class="breadcrumb">
		<el-breadcrumb separator=">">
			<el-breadcrumb-item :to="{ path: '/index' }" @click.native="clickIndex"
				>首页</el-breadcrumb-item
			>
			<el-breadcrumb-item v-for="item in curMenuList" :key="item.name">{{
				item.label
			}}</el-breadcrumb-item>
		</el-breadcrumb>
	</div>
</template>

<script>
export default {
	name: 'FrontAdminBreadcrumb',
	props: {
		curMenuList: {
			type: Array,
			// 面包屑列表[{path:'/system',label:'系统管理'},...]
			default: () => {
				return []
			},
		},
	},
	data() {
		return {}
	},
	methods: {
		clickIndex() {
			let curMenuList = [{ path: '/index', name: 'index', label: '首页' }]
			this.$store.commit('updateCurMenuList', curMenuList)
		},
	},
}
</script>

<style scoped></style>
