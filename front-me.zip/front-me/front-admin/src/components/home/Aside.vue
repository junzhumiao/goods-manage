<template>
	<div class="aside" style="color: white">
		<transition name="fade">
			<el-menu
				:router="true"
				:collapse="isCollapse"
				:style="menuStyle"
				:background-color="backgroundColor"
				:text-color="color"
				style="height: 100%"
			>
				<span v-if="isShowLogo">
					<el-menu-item v-if="menuTitle.label" style="color: white !important">
						<img
							:src="menuTitle.imgUrl"
							width="16"
							height="16"
							style="margin: 0 10px 0 0"
						/>
						<span slot="title" v-if="!isCollapse">{{ menuTitle.label }}</span>
					</el-menu-item>
				</span>
				<!-- 只有一个根路由 -->
				<span v-for="item in routers" :key="item.label">
					<el-menu-item
						v-if="!item.children || item.children.length == 0"
						class="menu-item"
						@click="clickMenu(item)"
						:class="{
							'active-style': $route.path == item.path,
							'no-active-style': $route.path != item.path,
						}"
					>
						<i :class="item.icon"></i>
						<span slot="title" v-if="!isCollapse">{{ item.label }}</span>
					</el-menu-item>
					<!-- 根路由下面拥有子路由 -->
					<el-submenu
						:index="`/${item.path}`"
						v-else
						:style="{ color: color }"
						class="menu-item"
					>
						<template slot="title">
							<i :class="item.icon"></i>
							<span slot="title" v-if="!isCollapse">{{ item.label }}</span>
						</template>
						<el-menu-item-group>
							<el-menu-item
								v-for="cItem in item.children"
								:key="cItem.label"
								@click="clickMenu({ ...cItem, parent: item })"
								:class="{
									'active-style': $route.path == cItem.path,
									'no-active-style': $route.path != cItem.path,
								}"
							>
								<i :class="cItem.icon"></i>
								{{ cItem.label }}
							</el-menu-item>
						</el-menu-item-group>
					</el-submenu>
				</span>
			</el-menu>
		</transition>
	</div>
</template>

<script>
export default {
	name: "FrontAdminAside",
	props: {
		isCollapse: {
			// 是否收缩导航
			type: Boolean,
			default: false,
		},
		routers: {
			// 路由列表
			type: Array,
			default: () => [],
		},
		menuTitle: {
			// 导航菜单的标题
			type: Object,
			default: () => {},
		},
		backgroundColor: {
			// 导航背景色
			type: String,
			default: "#304156",
		},
		color: {
			// 导航标题颜色
			type: String,
			default: "#ffffff",
		},
	},
	data() {
		return {
			height: 100,
		}
	},
	computed: {
		menuStyle() {
			return this.isCollapse ? {} : { width: "200px" }
		},
		isShowLogo() {
			return this.$store.state.globalSet.showLogo
		},
	},

	mounted() {},

	methods: {
		clickMenu(item) {
			this.$emit("click-menu", item)
		},
	},
}
</script>

<style scoped>
.no-active-style {
	color: white !important;
}
.active-style {
	color: rgb(17, 122, 232) !important;
}
.menu-item {
	text-align: start;
}
.fade-enter-active,
.fade-leave-active {
	transition: opacity 0.5s;
}
.fade-enter,
.fade-leave-to {
	opacity: 0;
}
</style>
