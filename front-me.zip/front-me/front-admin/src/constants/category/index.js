const columns = ["分类编号", "分类名称", "状态", "创建时间", "修改时间"]


export {
    columns
}