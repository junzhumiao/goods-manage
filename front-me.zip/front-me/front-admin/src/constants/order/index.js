const statusOptions = [
    {
        value: "0",
        label: "待支付",
    },
    {
        value: "1",
        label: "未发货",
    },
    {
        value: "2",
        label: "已发货",
    },
    {
        value: "3",
        label: "已完成",
    },
]
const refundOptions = [
    {
        value: "0",
        label: "未退款",
    },
    {
        value: "1",
        label: "退款",
    },
]
const cancelOptions = [
    {
        value: "0",
        label: "未取消",
    },
    {
        value: "1",
        label: "取消",
    },
]

const statusVal = {
    0: "待支付",
    1: "未发货",
    2: "已发货",
    3: "已完成",
}

const cancelVal = {
    0: "未取消",
    1: "取消",
}

const refundVal = {
    0: "未退款",
    1: "退款",
}

const orderColor = {
    0: "warning",
    1: "info",
    2: "primary",
    3: "success",
}
const columns = ["订单编号", "订单序列号", "用户编号", "总价格", "交易数量", "状态"]


export {
    columns,
    statusOptions,
    cancelOptions,
    refundOptions,
    statusVal,
    cancelVal,
    refundVal,
    orderColor,
}