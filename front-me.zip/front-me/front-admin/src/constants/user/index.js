const columns = ["用户名称", "用户昵称", "用户编号", "手机号码", "状态", "创建时间", "头像", "性别"]
const sexOptions = [
    {
        value: "0",
        label: "男",
    },
    {
        value: "1",
        label: "女",
    },
    {
        value: "2",
        label: "未知",
    },
]


export {
    sexOptions,
    columns
}