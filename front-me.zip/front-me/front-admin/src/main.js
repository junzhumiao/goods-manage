import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

import VueJsonPretty from 'vue-json-pretty';
import 'vue-json-pretty/lib/styles.css';

import echarts from 'echarts';
import VueCropper from 'vue-cropper';

import "./main.scss"
import $Tool from './utils/tool';
import plugin from './utils/plugin';




Vue.component("vue-json-pretty", VueJsonPretty)
Vue.use(ElementUI)
Vue.use(VueCropper)


// 使用插件
$Tool.usePlugin(Vue.prototype, plugin)
Vue.prototype.$echarts = echarts
Vue.prototype.$Tool = $Tool
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
