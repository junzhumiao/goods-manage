<template>
	<div class="druid">
		<iframe
			src="/api/druid/index.html"
			sandbox="allow-scripts"
			scrolling="no"
			frameborder="0"
			style="height: calc(100vh - 100px); width: 100%"
		></iframe>
	</div>
</template>

<script>
export default {
	name: "FrontDruid",

	data() {
		return {}
	},

	mounted() {
		this.loading(this, "正在加载数据监控数据!")
		setTimeout(() => {
			this.closeLoading()
		}, 500)
	},

	methods: {},
}
</script>

<style lang="scss" scoped></style>
