<template>
	<div class="user">咨询信息页面 ...待完善</div>
</template>

<script>
export default {
	name: "FrontInfo",

	data() {
		return {}
	},

	mounted() {},

	methods: {},
}
</script>

<style lang="scss" scoped></style>
