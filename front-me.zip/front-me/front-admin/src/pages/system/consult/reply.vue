<template>
	<div class="user">咨询回复页面 ...待完善</div>
</template>

<script>
export default {
	name: "FrontReply",

	data() {
		return {}
	},

	mounted() {},

	methods: {},
}
</script>

<style lang="scss" scoped></style>
