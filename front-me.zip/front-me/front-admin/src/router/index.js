import Vue from 'vue'
import VueRouter from 'vue-router'
import $Store from '@/store'

const originalPush = VueRouter.prototype.push

VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}


// 登录、注册
import Login from '@/pages/login'
import Register from '@/pages/login/register.vue'
// home
import MixHome from '@/pages/MixHome.vue'
// 个人中心
import UserProfile from '@/pages/user-profile'
// 首页
import Index from '@/pages/index'
// 系统管理
import User from '@/pages/system/user'
import Farmer from '@/pages/system/farmer'
import Category from '@/pages/system/category'
import Goods from '@/pages/system/goods'
import Order from '@/pages/system/order'
import ConsultInfo from '@/pages/system/consult/info.vue'
import ConsultReply from '@/pages/system/consult/reply.vue'
// 系统监控
import Server from '@/pages/monitor/server'
import Druid from '@/pages/monitor/druid'
import Chain from '@/pages/monitor/chain'
import Online from '@/pages/monitor/online'
import Cache from '@/pages/monitor/cache'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: MixHome,
    children: [
      // 用户中心
      {
        path: 'user/profile',
        name: 'userProfile',
        component: UserProfile
      },
      // 首页
      {
        path: 'index',
        name: 'index',
        component: Index
      },
      // 系统管理
      {
        path: 'system/user',
        name: 'systemUser',
        component: User
      },
      {
        path: 'system/farmer',
        name: 'systemFarmer',
        component: Farmer
      },
      {
        path: 'system/category',
        name: 'systemCategory',
        component: Category
      },
      {
        path: 'system/goods',
        name: 'systemGoods',
        component: Goods
      },
      {
        path: 'system/order',
        name: 'systemOrder',
        component: Order
      },
      {
        path: 'system/consult/info',
        name: 'consultInfo',
        component: ConsultInfo
      },
      {
        path: 'system/consult/reply',
        name: 'consultReply',
        component: ConsultReply
      },
      // 系统监控
      {
        path: '/monitor/server',
        name: 'monitorServer',
        component: Server
      },
      {
        path: '/monitor/druid',
        name: 'monitorDruid',
        component: Druid
      },
      {
        path: '/monitor/chain',
        name: 'monitorChain',
        component: Chain
      },
      {
        path: '/monitor/online',
        name: 'monitorOnline',
        component: Online
      },
      {
        path: '/monitor/cache',
        name: 'monitorCache',
        component: Cache
      },
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/register',
    name: 'register',
    component: Register
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})


router.beforeEach((to, form, next) => {
  if (to.path == '/login' || to.path == '/register') {
    next()
    return
  }

  let token = $Store.state.token
  if (!token) {
    next({
      path: '/login',
      redirect: to.fullPath // 登录之后跳转to页面
    })
    return
  }
  next()
})

export default router
