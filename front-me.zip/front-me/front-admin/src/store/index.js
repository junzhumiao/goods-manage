import Vue from "vue"
import Vuex from "vuex"
import $Tool from "@/utils/tool"

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    // 中断请求令牌
    abortCon: null,
    XClientId: $Tool.getStorage("X-Client-Id") ? $Tool.getStorage("X-Client-Id") : "",
    token: $Tool.getStorage("token") ? $Tool.getStorage("token") : "",
    user: null,
    curMenuList: [],
    tagList: [
      {
        path: "/index",
        name: "index",
        label: "首页",
      },
    ],
    globalSet: $Tool.getStorage("globalSet")
      ? $Tool.getStorage("globalSet")
      : {
        showLogo: true,
        naviColor: '#304156'
      },
  },
  getters: {},
  // 虽然有些依赖本地存储,但是修改本地同时,也有修改state,保证即时响应
  mutations: {
    changeAbortCon(state, con) {
      state.abortCon = con
    },
    changeUser(state, user) {
      state.user = user
    },
    changeToken(state, token) {
      state.token = token
      $Tool.setStorage("token", token)
    },
    login(state, { user, token }) {
      state.user = user
      state.token = token
      $Tool.setStorage("token", token)
    },
    changeXClientId(state, uuid) {
      // if null的就设置
      if (!state.XClientId) {
        state.XClientId = uuid
        $Tool.setStorage("X-Client-Id", uuid)
      }
    },
    changeGlobalSet(state, obj) {
      state.globalSet = obj
      $Tool.setStorage("globalSet", obj)
    },
    updateCurMenuList(state, curMenuList) {
      state.curMenuList = curMenuList.filter((item) => {
        return item.path != "/index"
      })
    },
    updateTagList(state, tag) {
      for (let i = 0; i < state.tagList.length; i++) {
        const oTag = state.tagList[i]
        if (oTag.path == tag.path) {
          return
        }
      }
      state.tagList.push(tag)
    },
    removeTag(state, path) {
      state.tagList = state.tagList.filter((item) => {
        return item.path != path
      })
    },
    // 修改全局配置
    updateGlobalSet(state, newSet) {
      state.globalSet = newSet
    },
  },
  actions: {},
  modules: {},
})

