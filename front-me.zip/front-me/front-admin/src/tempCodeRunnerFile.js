        console.log(12);
