
// let menus = [
//     {
//         "menuId": 2,
//         "menuPath": "/system",
//         "menuName": "系统管理",
//         "menuIcon": "el-icon-s-tools",
//         "rootId": -1,
//         "children": [
//             {
//                 "menuId": 4,
//                 "menuPath": "/system/farmer",
//                 "menuName": "农户管理",
//                 "menuIcon": "el-icon-user",
//                 "rootId": 2,
//                 "children": null
//             },
//             {
//                 "menuId": 5,
//                 "menuPath": "/system/category",
//                 "menuName": "产品分类管理",
//                 "menuIcon": "el-icon-menu",
//                 "rootId": 2,
//                 "children": null
//             },
//             {
//                 "menuId": 6,
//                 "menuPath": "/system/goods",
//                 "menuName": "农产品管理",
//                 "menuIcon": "el-icon-s-goods\r\nel-icon-s-goods\r\nel-icon-s-goods",
//                 "rootId": 2,
//                 "children": null
//             },
//             {
//                 "menuId": 7,
//                 "menuPath": "/system/consult/info",
//                 "menuName": "咨询信息管理",
//                 "menuIcon": "el-icon-message",
//                 "rootId": 2,
//                 "children": null
//             },
//             {
//                 "menuId": 8,
//                 "menuPath": "/system/consult/reply",
//                 "menuName": "咨询回复管理",
//                 "menuIcon": "el-icon-chat-dot-square",
//                 "rootId": 2,
//                 "children": null
//             },
//             {
//                 "menuId": 9,
//                 "menuPath": "/system/user",
//                 "menuName": "用户管理",
//                 "menuIcon": "el-icon-user-solid\r\nel-icon-user-solid",
//                 "rootId": 2,
//                 "children": null
//             },
//             {
//                 "menuId": 10,
//                 "menuPath": "/system/order",
//                 "menuName": "订单管理",
//                 "menuIcon": "el-icon-s-order",
//                 "rootId": 2,
//                 "children": null
//             }
//         ]
//     },
//     {
//         "menuId": 1,
//         "menuPath": "/home",
//         "menuName": "首页",
//         "menuIcon": "el-icon-s-home",
//         "rootId": -1,
//         "children": null
//     },
//     {
//         "menuId": 11,
//         "menuPath": "/monitor",
//         "menuName": "系统监控",
//         "menuIcon": "el-icon-monitor",
//         "rootId": -1,
//         "children": [
//             {
//                 "menuId": 12,
//                 "menuPath": "/monitor/server",
//                 "menuName": "服务监控",
//                 "menuIcon": "el-icon-cpu",
//                 "rootId": 11,
//                 "children": null
//             },
//             {
//                 "menuId": 13,
//                 "menuPath": "/monitor/druid",
//                 "menuName": "数据监控",
//                 "menuIcon": "el-icon-data-line",
//                 "rootId": 11,
//                 "children": null
//             },
//             {
//                 "menuId": 14,
//                 "menuPath": "/monitor/online",
//                 "menuName": "在线用户",
//                 "menuIcon": "el-icon-s-data",
//                 "rootId": 11,
//                 "children": null
//             }
//         ]
//     }
// ]


// let pro = {
//     name: 'qhx',
//     age: 20
// }

// let pro1 = {
//     c: 20
// }

// pro1 = { ...pro1, ...pro }

// console.log(pro1);


// function handA() {

// }


// console.log(handA);


// 删除一个对象null,""字段
// let obj = {
//     name: '',
//     age: 20
// }

// for (const key in obj) {
//     if (Object.hasOwnProperty.call(obj, key)) {
//         let val = obj[key]
//         if (val == null || val == '') {
//             delete obj[key]
//         }
//     }
// }

// console.log(obj);

// let num = "20"


// console.log(num.indexOf('.'));

// // 返回保留2位小数的字符串
// function retainTwo(val) {
//     let str = val + ''
//     if (str.indexOf('.') == -1) {
//         str += '.00'
//         return str

//     }
//     // 长度不够截取
//     let l = str.indexOf('.') + 3
//     let cha = str.length - l
//     if (cha >= 0) {
//         return str.substring(0, l)
//     } else {
//         cha = -cha
//         for (let i = 0; i < cha; i++) {
//             str += '0'
//         }
//         return str
//     }
// }
// console.log(retainTwo(num));

// let obj = {
//     name: ''
// }

// console.log(Object.keys(obj).length != 0);

// function matchStr(ta,...str){
//     console.log(str);
// }