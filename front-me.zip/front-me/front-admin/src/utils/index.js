/** 
 * tag(标签),面包屑工具类
 */
class TagCurMenu {

    /** 
     * 向vux存储当前路由对象(面包屑)、增添路由列表(tag)
     */
    static updateTagCurMenu(vm, item) {
        vm.$router.push({ path: item.path })
        // 卧槽,一个是item.path;怎么哦安短他是子路由,并且拿到其中的值
        let curMenuList = TagCurMenu.handlerObjConvertAry(item)
        // debugger
        vm.$store.commit('updateCurMenuList', curMenuList)

        // 将路由对象存储到Vuex的store里面
        vm.$store.commit('updateTagList', item)
    }

    /** 
     * 删除tag并更新当前面包屑路由
     */
    static deleteTagAndUpdateCurMenu(vm, tag) {
        let oTagList = vm.$store.state.tagList
        let activeIndex = null
        oTagList.forEach((item, index) => {
            // 找出删除元素的索引
            if (item.path == tag.path) {
                activeIndex = index
            }
        })

        vm.$store.commit('removeTag', tag.path) // 删除元素
        let nTagList = vm.$store.state.tagList
        vm.$router.push({ path: nTagList[activeIndex - 1].path })
        // 更新面包屑
        let curMenuList = TagCurMenu.handlerObjConvertAry(nTagList[activeIndex - 1])
        vm.$store.commit('updateCurMenuList', curMenuList)
    }

    /** 将tag格式转换为 [{path:'',name:'',..}, {path:'',..}]
    *
    * @param item {path:'',name',parent:{path:'',name:''}}
    * @return
    */
    static handlerObjConvertAry(item) {
        let ary = []
        item.parent ? ary.push({ ...item.parent }) : {}
        ary.push({ ...item })
        return ary
    }


}

export { TagCurMenu }