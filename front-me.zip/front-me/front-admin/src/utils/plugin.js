let loadingInstance = null

let plugin = {
    sucMes(vue, text) {
        vue.$message.success(text)
    },
    // 加载
    loading(vue, text) {
        loadingInstance = vue.$loading({
            lock: true,
            text,
            spinner: "el-icon-loading",
            background: "rgba(0, 0, 0, 0.7)",
        })
    },
    // 关闭加载
    closeLoading() {
        loadingInstance.close();
    },
    // 获取加载实例
    loadInstance() {
        return loadingInstance
    },
    // confirm弹框
    confirm(func, text, success, error = () => { }) {
        return func(text, '系统提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
        }).then(success)
            .catch(error)

    },
    // 输入框弹窗
    prompt({ func, text, errMes }, validFunc, success, error = () => { }) {
        return func(text, '系统提示',
            {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                inputValidator: validFunc,
                inputErrorMessage: errMes,
            }).then(success)
            .catch(error)
    },
    // 校验表单(封装表单校验逻辑)/卧槽,这还是回调同步?
    checkForm(vm, formName) {
        let end = false
        vm.$refs[formName].validate((valid) => {
            end = valid
        })
        return end
    },

}

export default plugin