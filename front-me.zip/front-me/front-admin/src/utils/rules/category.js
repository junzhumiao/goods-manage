import { CategoryConstants } from "@/constants"

let verifyCategoryName = (value) => {
    if (value.length >= CategoryConstants.CATEGORY_NAME_MIN_LEN && value.length <= CategoryConstants.CATEGORY_NAME_MAX_LEN) {
        return true
    }
    return false
}

var checkCategoryName = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("产品分类名不能为空"))
    } else if (!verifyCategoryName(value)) {
        return callback(new Error(CategoryConstants.CATEGORY_NAME_NOT_MATCH))
    } else {
        callback()
    }
}





let submitRules = () => {
    return {
        categoryName: [{ validator: checkCategoryName, trigger: "blur" }],
    }
}



export {
    submitRules
}