import { GoodsConstants } from "@/constants"

let verifyGoodsName = (value) => {
    if (value.length >= GoodsConstants.GOODS_NAME_MIN_LEN && value.length <= GoodsConstants.GOODS_NAME_MAX_LEN) {
        return true
    }
    return false
}

var checkGoodsName = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("产品名称不能为空"))
    } else if (!verifyGoodsName(value)) {
        return callback(new Error(GoodsConstants.GOODS_NAME_NOT_MATCH))
    } else {
        callback()
    }
}

var checkCategoryIds = (rule, value, callback) => {
    if (value.length == 0) {
        return callback(new Error("至少选择一个分类标签"))
    } else {
        callback()
    }
}

var checkShopId = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("所属商家编号不能为空"))
    } else {
        callback()
    }
}




let submitRules = () => {
    return {
        goodsName: [{ validator: checkGoodsName, trigger: "blur" }],
        categoryIds: [{ validator: checkCategoryIds, trigger: "blur" }],
        shopId: [{ validator: checkShopId, trigger: "blur" }]
    }
}



export {
    submitRules
}