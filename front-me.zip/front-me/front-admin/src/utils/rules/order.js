import UserUtil from "@/utils/user-util"



var checkShopId = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("产品编号不能为空"))
    } else {
        callback()
    }
}


var checkBuyerId = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("用户编号不能为空"))
    } else {
        callback()
    }
}

var checkGoodsId = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("农产品编号不能为空"))
    } else {
        callback()
    }
}


var checkReceiverName = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("接受者姓名不能为空"))
    } else {
        callback()
    }
}

var checkReceiverPhone = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("接受者电话不能为空"))
    } else if (!UserUtil.verifyPhone(value)) {
        return callback(new Error("接受者电话格式不对"))
    } else {
        callback()
    }
}


var checkReceiverAddress = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("接受者地址不能为空"))
    } else {
        callback()
    }
}


var checkSenderName = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("发送者姓名不能为空"))
    } else {
        callback()
    }
}

var checkSenderPhone = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("发送者电话不能为空"))
    } else if (!UserUtil.verifyPhone(value)) {
        return callback(new Error("发送者电话格式不对"))
    } else {
        callback()
    }
}

var checkSenderAddress = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("发送者地址不能为空"))
    } else {
        callback()
    }
}

var checkExpressName = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("快递名称不能为空"))
    } else {
        callback()
    }
}

var checkExpressNum = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("快递单号不能为空"))
    } else {
        callback()
    }
}

let submitRules = () => {
    return {
        shopId: [{ validator: checkShopId, trigger: "blur" }],
        buyerId: [{ validator: checkBuyerId, trigger: "blur" }],
        goodsId: [{ validator: checkGoodsId, trigger: "blur" }],
        receiverName: [{ validator: checkReceiverName, trigger: "blur" }],
        receiverPhone: [{ validator: checkReceiverPhone, trigger: "blur" }],
        receiverAddress: [{ validator: checkReceiverAddress, trigger: "blur" }],
        senderName: [{ validator: checkSenderName, trigger: "blur" }],
        senderPhone: [{ validator: checkSenderPhone, trigger: "blur" }],
        senderAddress: [{ validator: checkSenderAddress, trigger: "blur" }],
        expressName: [{ validator: checkExpressName, trigger: "blur" }],
        expressNum: [{ validator: checkExpressNum, trigger: "blur" }],
    }
}



export {
    submitRules
}