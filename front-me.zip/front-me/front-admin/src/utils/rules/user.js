import { UserConstants } from "@/constants"
import UserUtil from "@/utils/user-util"


var checkUsername = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("用户名称不能为空"))
    } else if (!UserUtil.verifyUsername(value)) {
        return callback(new Error(UserConstants.USERNAME_NOT_MATCH))
    } else {
        callback()
    }
}



var checkNickname = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("用户昵称不能为空"))
    } else if (!UserUtil.verifyUsername(value)) {
        return callback(new Error(UserConstants.NICKNAME_NOT_MATCH))
    } else {
        callback()
    }
}

var checkPass = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("密码不能为空"))
    } else if (!UserUtil.verifyPassword(value)) {
        return callback(new Error(UserConstants.PASSWORD_NOT_MATCH))
    } else {
        callback()
    }
}
var checkPhone = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("电话不能为空"))
    } else if (!UserUtil.verifyPhone(value)) {
        return callback(new Error(UserConstants.PHONE_NOT_MATCH))
    } else {
        callback()
    }
}

var checkEmail = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("邮箱不能为空"))
    } else if (!UserUtil.verifyEmail(value)) {
        return callback(new Error(UserConstants.EMAIL_NOT_MATCH))
    } else {
        callback()
    }
}


let checkOldPass = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("旧密码不能为空"))
    }
    if (!UserUtil.verifyPassword(value)) {
        return callback(new Error("旧密码格式不对"))
    } else {
        callback()
    }
}


let checkCode = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("验证码不能为空"))
    }
    else {
        callback()
    }
}

// 用户管理
let submitRules = () => {
    return {
        username: [{ validator: checkUsername, trigger: "blur" }],
        nickname: [{ validator: checkNickname, trigger: "blur" }],
        password: [{ validator: checkPass, trigger: "blur" }],
        phone: [{ validator: checkPhone, trigger: "blur" }],
    }
}

let registerRules = () => {
    var checkRegisterUsername = (rule, value, callback) => {
        if (!value) {
            callback()
        } else if (!UserUtil.verifyUsername(value)) {
            return callback(new Error(UserConstants.USERNAME_NOT_MATCH))
        } else {
            callback()
        }
    }
    return {
        username: [{ validator: checkRegisterUsername, trigger: "blur" }],
        password: [{ validator: checkPass, trigger: "blur" }],
        phone: [{ validator: checkPhone, trigger: "blur" }],
    }
}

let loginRules = () => {
    return {
        username: [{ validator: checkUsername, trigger: "blur" }],
        password: [{ validator: checkPass, trigger: "blur" }],
        code: [{ validator: checkCode, trigger: "blur" }],
    }
}


// 个人中心

let baseUserRules = () => {
    return {
        nickname: [{ validator: checkNickname, trigger: "blur" }],
        phone: [{ validator: checkPhone, trigger: "blur" }],
        email: [{ validator: checkEmail, trigger: "blur" }],
    }
}


let passRules = () => {
    return {
        oldPass: [{ validator: checkOldPass, trigger: "blur" }],
    }
}


export {
    submitRules,
    registerRules,
    loginRules,
    baseUserRules,
    passRules
}