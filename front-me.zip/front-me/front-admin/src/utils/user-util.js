import { UserConstants } from "@/constants"

class UserUtil {
    static verifyPassword(val) {
        if (val.length < UserConstants.PASSWORD_MIN_LENGTH || val.length > UserConstants.PASSWORD_MAX_LENGTH) {
            return false
        }
        return true
    }

    static verifyUsername(val) {
        if (val.length < UserConstants.USERNAME_MIN_LENGTH || val.length > UserConstants.USERNAME_MAX_LENGTH) {
            return false
        }
        return true
    }

    static verifyPhone(val) {
        return UserConstants.MOBILE_PHONE_NUMBER_PATTERN.test(val)
    }

    static verifyEmail(val) {
        return UserConstants.EMAIL_PATTERN.test(val)
    }
}

export default UserUtil;