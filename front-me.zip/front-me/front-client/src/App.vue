<template>
	<div id="app" class="slid-block" style="height: 100vh; overflow-y: auto">
		<router-view />
	</div>
</template>

<style>
#app {
	width: 100vw;
	height: 100vh;
}
</style>

