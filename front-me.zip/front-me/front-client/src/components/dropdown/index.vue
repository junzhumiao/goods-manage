<template>
	<el-dropdown style="height: 100%">
		<span class="el-dropdown-link" style="height: 100%; display: block">
			{{ title }}<i class="el-icon-arrow-down el-icon--right"></i>
		</span>
		<el-dropdown-menu slot="dropdown">
			<el-dropdown-item
				v-for="(item, index) in list"
				:key="index"
				@click.native="handleItem(item)"
				>{{ item.label }}</el-dropdown-item
			>
		</el-dropdown-menu>
	</el-dropdown>
</template>

<script>
export default {
	name: "FrontClientIndex",
	props: {
		title: {
			type: String,
			default: "",
		},
		list: {
			type: Array,
			default: () => [],
		},
	},

	data() {
		return {}
	},

	mounted() {},

	methods: {
		handleItem(item) {
			this.$emit("handleItem", item)
		},
	},
}
</script>

<style lang="scss" scoped></style>
