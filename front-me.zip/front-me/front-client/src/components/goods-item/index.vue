<template>
	<div class="goods-item" :class="column ? 'goods-item-c' : ''">
		<div class="goods-hover"></div>
		<div class="goods-img">
			<img :src="item.goodsImg" alt="农产品图片.png" />
		</div>
		<!-- 右半部分 -->
		<div :class="column ? 'goods-right-c' : ''">
			<div class="goods-title" :class="column ? 'goods-title-c' : ''">
				{{ item.goodsName }}
			</div>
			<div class="goods-tag chil-cen" v-show="item.tag" :class="column ? 'goods-tag-c' : ''">
				<span v-for="(item, index) in handleTag(item.tag)" :key="index">{{ item }}</span>
			</div>
			<div class="goods-bot" :class="column ? 'goods-bot-c' : ''">
				<div class="price">
					￥
					<span>{{ item.price }}</span>
				</div>
				<div class="buyer">
					<span> {{ handlerBuyer(item.sold) }} </span>
					人购买
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	name: "FrontGoodsItem",
	props: {
		item: {
			type: Object,
			default: () => {},
		},
		// 列布局
		column: {
			type: Boolean,
			default: false,
		},
	},
	methods: {
		handlerBuyer(val) {
			let res = ""
			if (val <= 0) {
				return "0"
			}
			let str = val + ""
			let len = str.length
			if (len == 1) {
				return "0"
			}
			res += str.charAt(0)
			for (let i = 0; i < len - 1; i++) {
				res += "0"
			}
			res += "+"
			return res
		},
		handleTag(tag) {
			return tag.split("|")
		},
	},
}
</script>

<style lang="scss" scoped>
.goods-item {
	cursor: pointer;
	position: relative;
	width: 250px;
	height: 360px;
	padding: 8px;
}
.goods-hover {
	top: 0px;
	left: 0px;
	right: 0px;
	bottom: 0px;
	position: absolute;
}
.goods-hover:hover {
	border-radius: 5px;
	border: 2px solid green;
}
.goods-img img {
	border-radius: 5px;
	height: 240px;
	width: 240px;
}

.goods-title {
	height: 45px;
	width: 100%;
	overflow: hidden;
}
.goods-tag {
	height: 35px;
	overflow: hidden;
	justify-content: start;
	span {
		margin-right: 8px;
		padding: 2px;
		border-radius: 5px;
		border: 2px solid green;
		background: rgba(0, 128, 0, 0.8);
		color: white;
	}
}

.goods-bot {
	display: flex;
	align-items: center;
	.price,
	.buyer {
		padding-left: 5px;
		font-size: 16px;
	}

	.price {
		color: green;
		span {
			font-size: 24px;
		}
	}

	.buyer {
		color: #50607a;
	}
}

// 切换列布局显示样式
.goods-item-c {
	display: flex;
	width: 100%;
	height: 255px;
}
.goods-right-c {
	position: relative;
	padding-left: 10px;
	width: 100%;
}
.goods-title-c {
	width: 100%;
	margin-top: 10px;
}
.goods-tag-c {
	position: absolute;
	bottom: 20px;
}
.goods-bot-c {
	position: absolute;
	bottom: 60px;
	right: 150px;
}
</style>
