<template>
	<div class="goods-list chil-cen">
		<goods-item
			:column="column"
			:item="item"
			v-for="(item, index) in list"
			:key="index"
			@click.native="handleItem(item)"
		></goods-item>
	</div>
</template>

<script>
import GoodsItem from "@/components/goods-item/index.vue"
export default {
	name: "FrontGoodsList",
	props: {
		list: {
			type: Array,
			default: () => [],
		},
		column: {
			type: Boolean,
			default: false,
		},
	},
	components: {
		GoodsItem,
	},
	data() {
		return {}
	},
	methods: {
		handleItem(item) {
			this.$emit("handleItem", item)
		},
	},
}
</script>

<style lang="scss" scoped>
.goods-list {
	width: 100%;
	padding: 8px;
}
</style>
