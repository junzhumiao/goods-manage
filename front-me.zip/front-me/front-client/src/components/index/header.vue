<template>
	<div class="header card">
		<el-row class="head-top banner">
			<!-- head-top-左边 -->
			<el-col :span="12" style="display: flex">
				<div class="h-top-user">
					<!-- TODO:这里没注册是动态的 -->
					<el-dropdown style="height: 100%">
						<span>admin<i class="el-icon-arrow-down el-icon--right"></i></span>
						<el-dropdown-menu slot="dropdown" style="position: relative">
							<el-dropdown-item class="chil-cen">
								<div class="avatar">
									<img :src="user.avatar" alt="用户头像" />
								</div>
								<div class="username">
									{{ user.username }}
								</div>
								<div style="height: 30px; width: 70px"></div>
								<div class="opt">
									<span @click="goPath('/my/account')">账号管理</span>
									<span>|</span>
									<span @click="goLogout">退出</span>
								</div>
							</el-dropdown-item>
						</el-dropdown-menu>
					</el-dropdown>
				</div>
				<div>逛云农,享受人生</div>
			</el-col>
			<!-- head-top-右边 -->
			<el-col :offset="9" :span="10" style="display: flex" class="h-top-right">
				<div @click="goPath('/index')" v-show="$route.path != '/index'">回到首页</div>
				<div>
					<Dropdown title="我的云农" :list="routers1" @handleItem="goPath"></Dropdown>
				</div>
				<div>购物车</div>
				<div>
					<Dropdown title="收藏夹" :list="routers2" @handleItem="goPath"></Dropdown>
				</div>
				<div>
					<router-link to="/category" style="color: black; text-decoration: none"
						>商品分类</router-link
					>
				</div>
				<div>
					<Dropdown title="联系客服" :list="routers3" @handleItem="goPath"></Dropdown>
				</div>
			</el-col>
		</el-row>
	</div>
</template>

<script>
import { routers1, routers2, routers3 } from "@/constanst/index"
import Dropdown from "@/components/dropdown/index.vue"
export default {
	name: "FrontHeader",
	props: {
		user: {
			type: Object,
			default: () => {},
		},
	},
	data() {
		return {
			routers1: routers1,
			routers2: routers2,
			routers3: routers3,
			search: "",
		}
	},
	methods: {
		goPath({ path }) {
			this.$router.push(path)
		},
		goLogout() {
			console.log("退出接口!")
		},
		goPath(path) {
			this.$router.push(path)
		},
	},
	components: {
		Dropdown,
	},
}
</script>

<style lang="scss" scoped>
.head-top {
	display: flex;
	height: 36px;

	.el-col > div {
		margin-left: 15px;
		border-radius: 5px;
		cursor: pointer;
		transition: all 0.5s;
	}
	.el-col > div:hover {
		background: rgba(0, 0, 0, 0.5);
	}
}

.avatar {
	img {
		height: 60px;
		width: 60px;
	}
}

.username {
	padding: 10px;
}

.opt {
	position: absolute;
	right: 2px;
	top: 2px;

	span:first-child {
		color: #67c23a;
	}
	span:nth-child(2) {
		padding: 0 5px;
	}
}

.head-bottom {
	height: 116px;
	padding: 28px 0 16px 0;

	.logo {
		display: block;
		width: 240px;
		height: 72px;
		background-position: center;
		background-image: url(@/static/image/logo.png);
	}

	.search-but {
		color: white;
		border: 2px solid #67c23a;
		background: #67c23a;
	}
}
</style>
