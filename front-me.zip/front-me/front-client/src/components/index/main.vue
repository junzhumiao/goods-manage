<template>
	<div class="main banner card">
		<el-row class="main-top">
			<!-- 分类 -->
			<el-col class="category row card" :span="5">
				<div class="title">分类</div>
				<div
					style="cursor: pointer; border-radius: 0"
					class="circle"
					@click="handleCategory(item)"
					v-for="(item, index) in itemList"
					:key="index"
				>
					{{ item.categoryName }}
				</div>
			</el-col>
			<!-- 轮播图 -->
			<el-col class="carousel row card" :span="14">
				<el-carousel :interval="5000" loop arrow="always">
					<el-carousel-item v-for="(item, index) in imgList" :key="index">
						<img style="height: 100%; width: 100%" :src="item" alt="" />
					</el-carousel-item>
				</el-carousel>
			</el-col>
			<!-- 我的 -->
			<el-col class="my row card" :span="5">
				<div class="avatar chil-cen row-item">
					<img :src="avatar" />
				</div>
				<div class="title chil-cen row-item">{{ getDateNoon() }},云农用户</div>
				<div class="item-but chil-cen j-c-sb row-item">
					<el-button type="primary" @click="goPath('login')">登录</el-button>
					<el-button type="success" @click="goPath('register')">注册</el-button>
					<el-button>开店</el-button>
				</div>
				<div class="item-opts chil-cen j-c-sb row-item">
					<div
						class="chil-cen-c"
						v-for="(item, index) in itemOpts"
						:key="index"
						@click="goPath(item.path)"
					>
						<img :src="item.img" alt="未知图片" />
						<div>{{ item.name }}</div>
					</div>
				</div>
			</el-col>
		</el-row>
		<el-row class="main-bottom">
			<div class="title">猜你喜欢</div>
			<goods-list :list="goodsList" @handleItem="handleGoods"></goods-list>
		</el-row>
	</div>
</template>

<script>
import GoodsList from "@/components/goods-list/index.vue"
import { itemOpts } from "@/constanst/index"
export default {
	name: "FrontMain",
	components: {
		GoodsList,
	},
	data() {
		return {
			itemOpts: itemOpts,
		}
	},
	props: {
		itemList: {
			type: Array,
			default: () => [],
		},
		imgList: {
			type: Array,
			default: () => [],
		},
		avatar: {
			type: String,
			default: "",
		},
		goodsList: {
			type: Array,
			default: () => [],
		},
	},
	methods: {
		handleCategory(item) {
			this.$emit("handleCategory", item)
		},
		handleGoods(item) {
			this.$emit("handleGoods", item)
		},
		getDateNoon() {
			let hour = new Date().getHours()
			if (hour >= 7 && hour < 9) {
				return "早上好"
			}
			if (hour >= 9 && hour < 12) {
				return "上午好"
			}

			if (hour >= 12 && hour < 18) {
				return "下午好"
			}
			return "晚上好"
		},
		goPath(path) {
			this.$router.push(path)
		},
	},
}
</script>

<style lang="scss" scoped>
.title {
	padding: 8px 0 0 16px;
	font-size: 22px;
	font-weight: bolder;
}

.row {
	height: 100%;
	overflow: hidden;
}
.main-bottom {
	padding: 16px;
}

.main-top {
	display: flex;
	justify-content: center;
	padding: 16px;
	height: 416px;

	.carousel {
		margin-left: 16px;
	}
	.my {
		margin-left: 16px;
		.avatar {
			margin: 0 auto;
			img {
				width: 3.75rem;
				height: 3.75rem;
			}
		}

		.item-opts {
			> div {
				transition: all 0.5s;
				img {
					width: 80px;
				}
			}

			> div:hover {
				box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px, rgb(51, 51, 51) 0px 0px 0px 3px;
				background: rgba(0, 0, 0, 0.8);
				border-radius: 5px;
				color: white;
			}
		}
	}
}
</style>
