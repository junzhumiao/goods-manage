<template>
	<div class="pagination">
		<div @click="handleRemove" :class="isDown ? 'cross' : ''" style="cursor: pointer">
			{{ "<" }}
		</div>
		<div>
			<span>{{ page }}</span
			>/{{ totalPage }}
		</div>
		<div @click="handleAdd" :class="isOver ? 'cross' : ''" style="cursor: pointer">
			{{ ">" }}
		</div>
	</div>
</template>

<script>
export default {
	name: "FrontPagination",

	props: {
		pageSize: {
			type: Number,
			default: 5,
		},
		total: {
			type: Number,
			require: true,
		},
	},
	data() {
		return {
			page: 1,
			totalPage: 0,
		}
	},
	watch: {
		page() {
			this.handlePage()
		},
		pageSize() {
			this.handlePageSize()
		},
	},
	computed: {
		// 上越界
		isOver() {
			return this.page >= this.totalPage
		},
		// 下越界
		isDown() {
			return this.page <= 1
		},
	},
	mounted() {
		this.totalPage = this.total / this.pageSize
	},
	methods: {
		handleRemove() {
			let page = this.page
			if (this.isDown) {
				this.page = 1
				return
			}
			this.page = page - 1
		},
		handleAdd() {
			let page = this.page
			if (this.isOver) {
				this.page = totalPage
			}
			this.page = page + 1
		},
		handlePage() {
			this.$emit("handlePage", this.page)
		},
		handlePageSize() {
			this.$emit("handlePageSize", this.pageSize)
		},
	},
}
</script>

<style lang="scss" scoped>
.pagination {
	display: flex;
	align-items: center;
	> div {
		padding: 10px;
	}

	div:nth-child(2) span {
		color: green;
	}
}

.cross {
	font-size: 12px;
	color: rgb(37, 73, 105);
}
</style>
