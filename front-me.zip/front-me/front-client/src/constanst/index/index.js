let routers1 = [
    {
        label: "我购买农产品",
        path: "/my/order",
    },
    {
        label: "我的足迹",
        path: "/my/record",
    },
]
let routers2 = [
    {
        label: "农产品收藏",
        path: "/my/collect/goods",
    },
    {
        label: "商家收藏",
        path: "/my/collect/shop",
    },
]
let routers3 = [
    {
        label: "官方客服",
        path: "/message/admin",
    },
    {
        label: "意见反馈",
        path: "/feedback",
    },
    {
        label: "消息聊天",
        path: "/message/client",
    },
]

let itemOpts = [
    {
        path: "/my/collect/goods",
        name: "宝贝收藏",
        img: require("@/static/image/index/goods-collect.png"),
    },
    {
        path: "/my/shop/buy",
        name: "买过的店",
        img: require("@/static/image/index/shop-buy.png"),
    },
    {
        path: "/shop/collect/shop",
        name: "收藏的店",
        img: require("@/static/image/index/shop-collect.png"),
    },
    {
        path: "/my/record",
        name: "我的足迹",
        img: require("@/static/image/index/goods-record.png"),
    },
]
export {
    routers1,
    routers2,
    routers3,
    itemOpts
}