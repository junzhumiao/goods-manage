
const hMenus = [
    { name: "首页", path: "/my/index" },
    { name: "账号设置", path: "/my/account" },
]

// my/index下面
const menus = [
    {
        path: "/my/car",
        label: "我的购物车",
    },
    {
        path: "/my/order",
        label: "我的订单",
    },
    {
        path: "/shop/buy",
        label: "购买过的店铺",
    },
    {
        path: "/my/collect/goods",
        label: "我的收藏",
    },
    {
        path: "/my/comment",
        label: "评价管理",
    },
    {
        path: "/my/record",
        label: "我的足迹",
    },
]

// my/account 下面

export {
    menus,
    hMenus
}