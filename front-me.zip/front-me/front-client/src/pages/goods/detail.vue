<template>
	<div class="goods-detail">
		<el-row class="head card">
			<el-col class="logo" :span="3">
				<img src="@/static/image/goods/yn.png" />
			</el-col>
			<el-col class="search" :offset="3" :span="3">
				<el-input v-model="search" placeholder="搜索宝贝">
					<template slot="prepend">
						<i class="el-icon-search"></i>
					</template>
				</el-input>
			</el-col>
			<el-col>
				<el-button class="search-but" @click="goGoodsSearch">点我搜索</el-button>
			</el-col>
		</el-row>
	</div>
</template>

<script>
export default {
	name: "FrontClientDetail",

	data() {
		return {}
	},

	mounted() {
		let goodsId = $route.params.goodsId
		if (!goodsId) {
			this.msgWarning("访问空的商品详情!")
			this.$router.go(-1)
			return
		}
	},

	methods: {
		goGoodsSearch() {
			let search = this.search
		},
	},
}
</script>

<style lang="scss" scoped>
.head {
	.search {
	}
}

::v-deep .el-input__inner {
	border-bottom-right-radius: 10px;
	border-top-right-radius: 10px;
}

::v-deep .el-input-group__prepend {
	border-bottom-left-radius: 10px;
	border-top-left-radius: 10px;
}
</style>
