<template>
	<div class="goods-search card">
		<el-row class="row-item">
			<el-col :span="2"> <h4>所有农产品:</h4> </el-col>
			<el-col :span="2">
				{{ total }}
			</el-col>
		</el-row>
		<el-row>
			<el-divider></el-divider>
		</el-row>
		<el-row class="search-opt row-item">
			<el-col class="opt-left">
				<el-radio-group v-model="search.opt">
					<el-radio-button label="">综合</el-radio-button>
					<el-radio-button label="sold">销量</el-radio-button>
					<el-radio-button label="collect">信用(店铺收藏)</el-radio-button>
				</el-radio-group>
				<div class="price item">
					<span>价格</span>
					<el-input
						class="input"
						v-model.number="search.minPrice"
						placeholder="￥"
						clearable
					></el-input>
					<span>-</span>
					<el-input
						class="input"
						placeholder="￥"
						v-model.number="search.maxPrice"
						clearable
					>
					</el-input>
				</div>
				<el-button
					type="success"
					@click="confirmPrice"
					v-show="search.minPrice || search.maxPrice"
					>确定</el-button
				>
			</el-col>
			<el-col class="opt-right chil-cen" :span="3">
				<div class="menu icon">
					<img
						class="icon"
						:src="!column ? img.menuA : img.menu"
						@click="column = false"
						alt="菜单图片"
					/>
				</div>
				<div class="menu-c icon">
					<img
						class="icon"
						:src="column ? img.menuCA : img.menuC"
						@click="column = true"
						alt="横向菜单"
					/>
				</div>
				<pagination
					:total="total"
					:pageSize="search.pageSize"
					@handlePage="handlePage"
					@handlePageSize="handlePageSize"
				></pagination>
			</el-col>
		</el-row>
		<el-row class="row-item">
			<goods-list :list="list" @handleItem="handleGoods" :column="column"></goods-list>
		</el-row>
	</div>
</template>

<script>
import menu from "@/static/image/goods/menu.png"
import menuA from "@/static/image/goods/menu-a.png"
import menuC from "@/static/image/goods/menu-c.png"
import menuCA from "@/static/image/goods/menu-c-a.png"
import pagination from "@/components/pagination"
import GoodsList from "@/components/goods-list"
export default {
	name: "FrontGoodsSearch",

	data() {
		return {
			list: [],
			total: 300,
			search: {
				goodsName: "",
				categoryId: null,
				minPrice: null,
				maxPrice: null,
				opt: "",
				page: 1,
				pageSize: 20,
			},
			// 切换横纵布局
			column: false,
			img: {
				menu,
				menuA,
				menuC,
				menuCA,
			},
		}
	},
	components: {
		pagination,
		GoodsList,
	},
	watch: {
		"search.opt": {
			handler() {
				this.getGoodsList()
			},
		},
	},

	mounted() {
		this.init()
		for (let i = 0; i < 50; i++) {
			this.list.push({
				goodsId: i,
				goodsName: "农产品",
				price: 23,
				sold: 33,
				goodsImg: require("@/static/image/avatar.png"),
				tag: "精品|好吃|爱吃",
			})
		}
	},
	methods: {
		getGoodsList() {
			let search = { ...this.search }
			this.$Tool.removeNullFiled(search)
			console.log(search)
			//TODO axios
		},
		confirmPrice() {
			let search = { ...this.search }
			let isNum = /[0-9]+/
			if (!isNum.test(`${search.minPrice}`) || isNum.test(`${search.maxPrice}`)) {
				this.msgWarning("最小价格/最大价格要求必须输入数字！")
				return
			}
			this.getGoodsList()
		},
		init() {
			let query = this.$route.query

			if (query.goodsName) {
				this.search.goodsName = query.goodsName
			}
			if (query.categoryId) {
				this.search.categoryId = $route.query.categoryId
			}
		},
		handlePage(val) {
			this.search.page = val
		},
		handlePageSize(val) {
			this.search.pageSize = val
		},
		handleGoods({ goodsId }) {
			this.$router.push("/goods/detail/" + goodsId)
		},
	},
}
</script>

<style lang="scss" scoped>
.goods-search {
	.opt-left .item {
		padding: 0 30px;
	}

	.search-opt {
		display: flex;
		justify-content: space-around;
		.price {
			display: inline-block;
			.input {
				width: 82px;
			}
		}
	}

	.opt-right {
		justify-content: space-around;
		margin-right: 200px;
	}
}

::v-deep .el-radio-button__inner {
	font-size: 20px;
}
</style>
