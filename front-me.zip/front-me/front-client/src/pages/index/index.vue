<template>
	<div class="index">
		<el-row class="head-bottom banner">
			<el-col :span="4">
				<router-link to="#" class="logo"></router-link>
			</el-col>
			<el-col :span="13">
				<el-input v-model="search">
					<template slot="prepend">农产品</template>
					<el-button class="search-but" slot="append" @click="goGoodsSearch"
						>搜索</el-button
					>
				</el-input>
			</el-col>
		</el-row>
		<Main
			:item-list="list"
			:imgList="imgs"
			:avatar="user.avatar"
			:goods-list="goodsList"
			@handleCategory="goGoodsSearchByCategoryId"
			@handleGoods="goGoodsDetail"
		></Main>
		<el-row class="row-item chil-cen">
			<el-button type="success" @click="loadGoodsList">加载更多</el-button>
		</el-row>
	</div>
</template>

<script>
import Main from "@/components/index/main.vue"
export default {
	name: "FrontIndex",

	data() {
		return {
			search: "",
			page: {
				page: 1,
				pageSize: 20,
			},
			list: [],
			goodsList: [],
			imgs: [require("@/static/image/logo.png"), require("@/static/image/logo.png")],
			user: {
				username: "admin",
				avatar: require("@/static/image/avatar.png"),
			},
		}
	},
	components: {
		Main,
	},
	mounted() {
		for (let i = 0; i < 50; i++) {
			this.list.push({
				categoryName: "农产品",
				categoryId: i,
			})
			this.goodsList.push({
				goodsId: i,
				goodsName: "农产品",
				price: 23,
				sold: 33,
				goodsImg: require("@/static/image/avatar.png"),
				tag: "精品|好吃|爱吃",
			})
		}
	},
	methods: {
		goGoodsSearch() {
			let search = this.search
			if (!search) {
				this.msgSuccess("不能搜索空!")
				return
			}
			this.$router.push({
				path: "/goods/search",
				query: {
					goodsName: search,
				},
			})
		},
		goGoodsSearchByCategoryId({ categoryId }) {
			// item
			this.$router.push({
				path: "/goods/search",
				query: {
					categoryId,
				},
			})
		},
		goGoodsDetail({ goodsId }) {
			this.$router.push("/goods/detail/" + goodsId)
		},
		getGoodsList() {
			// TODO 数据添加到新的列表里
		},
		loadGoodsList() {
			let page = this.page
			page.page += 1
			this.getGoodsList()
		},
	},
}
</script>

<style lang="scss" scoped>
.head-bottom {
	height: 116px;
	padding: 28px 0 16px 0;

	.logo {
		display: block;
		width: 240px;
		height: 72px;
		background-position: center;
		background-image: url(@/static/image/logo.png);
	}

	.search-but {
		color: white;
		border: 2px solid #67c23a;
		background: #67c23a;
	}
}
</style>
