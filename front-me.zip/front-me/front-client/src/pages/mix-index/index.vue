<template>
	<div class="index">
		<Header :user="user"></Header>
		<!-- 混合页 -->
		<el-row class="banner">
			<router-view></router-view>
		</el-row>
	</div>
</template>

<script>
import Header from "@/components/index/header.vue"
import Main from "@/components/index/main.vue"
export default {
	name: "FrontIndex",
	data() {
		return {
			user: {
				username: "admin",
				avatar: require("@/static/image/avatar.png"),
			},
		}
	},

	components: {
		Header,
		Main,
	},
}
</script>

<style lang="scss" scoped></style>
