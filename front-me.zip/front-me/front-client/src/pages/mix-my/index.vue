<template>
	<div class="my">
		<el-row class="my-head">
			<el-row class="banner">
				<!-- 导航-头部 -->
				<el-col class="menu-head" :span="5">
					<img src="@/static/image/my/my-yn.png" alt="我的云农" />
				</el-col>
				<!-- 导航栏 -->
				<el-col :span="9">
					<el-menu class="menu" mode="horizontal" router>
						<el-menu-item
							class="menu-item"
							:index="item.path"
							v-for="(item, index) in hMenus"
							:key="index"
							>{{ item.name }}</el-menu-item
						>
					</el-menu>
				</el-col>
				<!-- 搜索框 -->
				<el-col :offset="9" :span="7">
					<el-input placeholder="请输入内容" v-model="search">
						<el-button slot="append" @click="goGoodsSearch">搜索</el-button>
					</el-input>
				</el-col>
			</el-row>
		</el-row>

		<el-row class="banner">
			<router-view></router-view>
		</el-row>
	</div>
</template>

<script>
import { hMenus } from "@/constanst/my"
export default {
	name: "FrontMy",

	data() {
		return {
			hMenus: hMenus,
			search: "",
		}
	},

	methods: {
		goGoodsSearch() {
			console.log(this.search)
			this.$router.push("/goods/search")
		},
	},
}
</script>

<style lang="scss" scoped>
.my-head {
	background: #85ce61;

	.banner {
		display: flex;
		align-items: center;
	}

	.menu {
		background: rgba(0, 0, 0, 0);
		border: 0;
		.menu-item {
			color: #ffffff;
			border: 0;
		}
		.menu-item:first-child {
			border-bottom: 2px solid white !important;
		}
		.menu-item:hover {
			background-color: rgba(133, 206, 97, 0.5) !important;
			color: black !important;
		}
	}
}
</style>
