<template>
	<div class="my-account">我的账号</div>
</template>

<script>
export default {
	name: "FrontMyAccount",

	data() {
		return {}
	},

	mounted() {},

	methods: {},
}
</script>

<style lang="scss" scoped></style>
