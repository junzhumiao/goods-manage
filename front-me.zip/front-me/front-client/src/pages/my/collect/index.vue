<template>
	<div class="my-collect">我的收藏{{ $route.params.type }}</div>
</template>

<script>
export default {
	name: "FrontMyCollect",

	data() {
		return {}
	},

	mounted() {},

	methods: {},
}
</script>

<style lang="scss" scoped></style>
