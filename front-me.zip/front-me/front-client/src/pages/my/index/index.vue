<template>
	<div class="my-index">
		<el-row>
			<el-col :span="3">
				<Aside :routers="menus" @click-menu="handleClickMenu"></Aside>
			</el-col>
			<el-col :span="21">
				<router-view></router-view>
			</el-col>
		</el-row>
	</div>
</template>

<script>
import Aside from "@/components/aside/index.vue"
import { menus } from "@/constanst/my"
export default {
	name: "FrontMyIndex",

	data() {
		return {
			menus: menus,
		}
	},
	components: {
		Aside,
	},

	methods: {
		handleClickMenu({ path }) {
			this.$router.push(path)
		},
	},
}
</script>

<style lang="scss" scoped></style>
