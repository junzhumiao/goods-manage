<template>
	<div class="my-card">我的购物车</div>
</template>

<script>
export default {
	name: "FrontCard",

	data() {
		return {}
	},

	mounted() {},

	methods: {},
}
</script>

<style lang="scss" scoped></style>
