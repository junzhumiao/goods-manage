import Vue from 'vue'
import VueRouter from 'vue-router'
// index
import MixIndex from '@/pages/mix-index'
import Index from '@/pages/index'
// 商品详情-搜索
import GoodsDetail from '@/pages/goods/detail.vue'
import GoodsSearch from '@/pages/goods/search.vue'

// 我的云农
import MixMy from '@/pages/mix-my'
// 我的云农首页
import MyIndex from '@/pages/my/index/index.vue'
import MyCar from '@/pages/my/car'
import MyCollect from '@/pages/my/collect'
// 我的云农账户设置
import MyAccount from '@/pages/my/account'

Vue.use(VueRouter)

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}



const routes = [
  {
    path: '/',
    redirect: '/index',
  },
  // 首页
  {
    path: '',
    component: MixIndex,
    children: [
      {
        path: '/index',
        name: 'index',
        component: Index,
      },
      // 商品
      {
        path: '/goods/detail/:goodsId',
        name: 'goodsDetail',
        component: GoodsDetail,
      },
      {
        path: '/goods/search',
        name: 'goodsSearch',
        component: GoodsSearch,
      },
    ]
  },
  // 我的
  {
    path: '/my',
    component: MixMy,
    redirect: '/my/index',
    children:
      [
        // 我的首页
        {
          path: 'index',
          name: 'myIndex',
          component: MyIndex,
          children: [
            {
              path: '/my/car',
              name: 'myCar',
              component: MyCar,
            },
            {
              path: '/my/collect/:type',
              name: 'myCollect',
              component: MyCollect,
            }
          ]
        },
        // 我的账户设置
        {
          path: 'account',
          name: 'account',
          component: MyAccount
        },
      ]
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
