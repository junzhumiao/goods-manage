let tool = {
    // 注册插件
    usePlugin(org, plugin) {
        for (const key in plugin) {
            org[key] = plugin[key]
        }
    },
    // 删除对象空值字段
    removeNullFiled(obj) {
        let nObj = { ...obj }
        for (const key in nObj) {
            if (Object.hasOwnProperty.call(nObj, key)) {
                let val = nObj[key]
                if (val == null || val == '') {
                    delete nObj[key] // if null,删除该字段
                }
                if (nObj.length && nObj.length === 0) {
                    delete nObj[key]
                }
            }
        }
        return nObj
    },
}
export default tool;